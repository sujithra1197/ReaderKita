package pages;

public class LoginPage {

}
